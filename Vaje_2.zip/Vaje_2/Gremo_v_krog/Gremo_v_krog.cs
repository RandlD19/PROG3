﻿using System;

namespace Gremo_v_krog
{
    class Gremo_v_krog
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
