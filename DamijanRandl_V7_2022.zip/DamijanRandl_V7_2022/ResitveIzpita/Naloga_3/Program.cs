﻿using System;
using System.IO;
using System.Collections.Generic;

namespace Naloga_3
{
    class MainClass
    {
        public static string Najveckrat_ponovi(string datoteka)
        {
            StreamReader branje = File.OpenText(datoteka);
            string vrstica;
            Dictionary<string, int> slovar_besed = new Dictionary<string, int>();

            while ((vrstica = branje.ReadLine()) != null)
            {
                string[] tab_besed = vrstica.Split(' ');
                foreach (string beseda in tab_besed)
                {
                    string beseda_brez = beseda.Trim();
                    if (beseda_brez.Length > 1)
                    {
                        if (slovar_besed.ContainsKey(beseda_brez))
                        {
                            slovar_besed[beseda_brez]++;
                        }
                        else
                        {
                            slovar_besed[beseda_brez] = 1;
                        }
                    }

                }

            }

            int naj_ponovitev = 0;
            string naj_beseda = "";

            foreach (string kljuc in slovar_besed.Keys)
            {
                if (slovar_besed[kljuc] > naj_ponovitev)
                {
                    naj_beseda = kljuc;
                    naj_ponovitev = slovar_besed[kljuc];
                }
            }

            return naj_beseda;


        }
        public static void Main(string[] args)
        {
            Console.WriteLine(Najveckrat_ponovi("knjiga.txt"));
        }
    }
}
