﻿using System;

namespace Naloga_1
{
    class MainClass
    {
        public static int fibonacijevo_zaporedje(int n)
        {
            int prvo = 0;
            int drugo = 1;

            for (int i = 0; i < n; i++)
            {
                int vsota = prvo + drugo;
                prvo = drugo;
                drugo = vsota;
            }
            return prvo;

        }
        public static void Main(string[] args)
        {
            for (int i = 0; i < 30; i++)
            {
                Console.WriteLine(fibonacijevo_zaporedje(i));
            }
        }
    }
}
