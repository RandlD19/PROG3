﻿using System;

namespace Naloga_2
{
    class MainClass
    {
        public static int vsota(int prvi, int drugi)
        {
            return prvi + drugi;
        }
        public static double vsota(double prvi, double drugi)
        {
            return prvi + drugi;
        }
        public static float vsota(float prvi, float drugi)
        {
            return prvi + drugi;
        }
        public static int vsota(string prvi, string drugi)
        {
            return prvi.Length + drugi.Length;
        }
        public static bool vsota(bool prvi, bool drugi)
        {
            if (prvi.Equals(drugi))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public static void Main(string[] args)
        {
            Console.WriteLine(vsota(1, 3));
            Console.WriteLine(vsota(1.3, 5.2));
            Console.WriteLine(vsota(3.4, 0.2));
            Console.WriteLine(vsota("niz1", "niz2"));
            Console.WriteLine(vsota("", "niz0"));
            Console.WriteLine(vsota(true, false));
            Console.WriteLine(vsota(true, true));
        }
    }
}
