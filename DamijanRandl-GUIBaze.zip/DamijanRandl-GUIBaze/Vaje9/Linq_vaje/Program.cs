﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Linq_vaje
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string[] sadje = { "banana", "ananas", "pomaračna", "kivi", "jabolko", "hruška", "mandarina", " mango", "jagoda", "ribez" };
            int[] stevila = { 2, 4, 3, 24, 6, 74, 132, 6545, 23, 87, 231, 2, 22, 98, 70, 21 };

            IEnumerable<string> drugo_sadje =
                from sadez in sadje
                where sadez.Count(p => p=='a') > 2
                orderby sadez[0], sadez.Length
                select sadez;

            foreach (string drugo in drugo_sadje)
            {
                Console.WriteLine(drugo);
            }
        }
    }
}
