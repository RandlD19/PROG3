﻿namespace Nobel
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.vnosLeta = new System.Windows.Forms.ComboBox();
            this.rezultati = new System.Windows.Forms.ListBox();
            this.isci_gumb = new System.Windows.Forms.Button();
            this.vnosPodrocja = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(71, 73);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(124, 32);
            this.label1.TabIndex = 0;
            this.label1.Text = "Vnesi leto:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(69, 162);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(178, 32);
            this.label2.TabIndex = 1;
            this.label2.Text = "Izberi področje:";
            // 
            // vnosLeta
            // 
            this.vnosLeta.FormattingEnabled = true;
            this.vnosLeta.Location = new System.Drawing.Point(201, 70);
            this.vnosLeta.Name = "vnosLeta";
            this.vnosLeta.Size = new System.Drawing.Size(199, 40);
            this.vnosLeta.TabIndex = 2;
            // 
            // rezultati
            // 
            this.rezultati.FormattingEnabled = true;
            this.rezultati.ItemHeight = 32;
            this.rezultati.Location = new System.Drawing.Point(523, 71);
            this.rezultati.Name = "rezultati";
            this.rezultati.Size = new System.Drawing.Size(872, 612);
            this.rezultati.TabIndex = 4;
            // 
            // isci_gumb
            // 
            this.isci_gumb.Location = new System.Drawing.Point(79, 489);
            this.isci_gumb.Name = "isci_gumb";
            this.isci_gumb.Size = new System.Drawing.Size(204, 46);
            this.isci_gumb.TabIndex = 5;
            this.isci_gumb.Text = "Išči!";
            this.isci_gumb.UseVisualStyleBackColor = true;
            this.isci_gumb.Click += new System.EventHandler(this.isci_gumb_Click);
            // 
            // vnosPodrocja
            // 
            this.vnosPodrocja.FormattingEnabled = true;
            this.vnosPodrocja.Items.AddRange(new object[] {
            "Chemistry",
            "Economics",
            "Literature",
            "Medicine",
            "Peace",
            "Physics"});
            this.vnosPodrocja.Location = new System.Drawing.Point(71, 219);
            this.vnosPodrocja.Name = "vnosPodrocja";
            this.vnosPodrocja.Size = new System.Drawing.Size(280, 40);
            this.vnosPodrocja.TabIndex = 6;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 32F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1427, 718);
            this.Controls.Add(this.vnosPodrocja);
            this.Controls.Add(this.isci_gumb);
            this.Controls.Add(this.rezultati);
            this.Controls.Add(this.vnosLeta);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label label1;
        private Label label2;
        private ComboBox vnosLeta;
        private ListBox rezultati;
        private Button isci_gumb;
        private ComboBox vnosPodrocja;
    }
}