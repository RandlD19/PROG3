using System.Data.SQLite;
using System.Data;

namespace Nobel
{
    public partial class Form1 : Form
    {
        string povNiz = @"Data Source=C:\Users\damij\Desktop\nobelDB.db; Version=3;";
        private SQLiteConnection povezava;
        public Form1()
        {
            InitializeComponent();
            this.povezava = new SQLiteConnection(this.povNiz);
            SQLiteCommand ukaz = new SQLiteCommand();
            ukaz.Connection = povezava;
            ukaz.CommandType = CommandType.Text;
            //string tekst = comboBox1.Text
            //int stevilo = int.Parse(comboBox1.Text)
            ukaz.CommandText = $"select distinct yr from nobel;";
            List<string> leta = new List<string>();
            povezava.Open();
            SQLiteDataReader reader = ukaz.ExecuteReader();
            while (reader.Read())
            {
                leta.Add($"{reader[0]}");
            }
            
            foreach (string leto in leta)
            {
                vnosLeta.Items.Add(leto);
            }

        
        }

        private void isci_gumb_Click(object sender, EventArgs e)
        {
            rezultati.Items.Clear();
            this.povezava = new SQLiteConnection(this.povNiz);
            SQLiteCommand ukaz = new SQLiteCommand();
            ukaz.Connection = povezava;
            ukaz.CommandType = CommandType.Text;
            //string tekst = comboBox1.Text
            //int stevilo = int.Parse(comboBox1.Text)
            
            try
            {
                ukaz.CommandText = $"select winner, yr, subject from nobel where yr = {int.Parse(vnosLeta.Text)} and subject = \'{vnosPodrocja.Text.ToString()}\';";
                List<string> dobitniki = new List<string>();
                povezava.Open();
                SQLiteDataReader reader = ukaz.ExecuteReader();
                int st = 0;
                while (reader.Read())
                {
                    dobitniki.Add($"{st + 1}. Leto: {reader[1]} --> Oseba: {reader[0]} --> Podro�je: {reader[2]}");
                    st++;
                }
                reader.Close();
                povezava.Close();
                int i = 0;
                foreach (string dobitnik in dobitniki)
                {
                    rezultati.Items.Add(dobitnik);
                    i++;
                }
            }
            catch (Exception)
            {
                povezava.Close();
                rezultati.Items.Add("Ni zadetkov!");
            }
            
        }
    }
}