﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Sql;
using System.Data.SQLite;

namespace Baze
{
    internal class Program
    {

        public SQLiteConnection povezava;
        public SQLiteDataAdapter data_adapter;
        public SQLiteCommand ukaz;
        
        static void Main(string[] args)
        {
            string povNiz = @"C:\Users\damij\Desktop\FMF\PROG3\Vaje\filmi.sqlite";
            povezava = new SQLiteConnection(povNiz);
            povezava.Open();
        }
    }
}
