﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Slovarji
{
    internal class Slovar: Dictionary<string, string>
    {
        public string spremenljivka;

        public Slovar()
        {

        }
        
        public bool TryAdd(string kljuc, string vrednost)
        {

            try
            {
                this.Add(kljuc, vrednost);
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public void Remove(string kljuc, out string spremenljivka)
        {

            try
            {
                spremenljivka = this[kljuc];
                this.Remove(kljuc);
            }
            catch (Exception)
            {
                spremenljivka = this.spremenljivka;
            }
        }

    }
}
