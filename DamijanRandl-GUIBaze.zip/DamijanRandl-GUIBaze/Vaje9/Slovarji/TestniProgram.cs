﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Slovarji
{
    
    internal class TestniProgram
    {
        static void Main(string[] args)
        {
            Slovar slovar = new Slovar();
            slovar.Add("TestniKljuc", "TestnaVrednost");
            slovar.TryAdd("neki", "ha");
        }
    }
        
    
}
