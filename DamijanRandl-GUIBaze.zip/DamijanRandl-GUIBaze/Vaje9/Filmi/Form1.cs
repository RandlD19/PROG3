using System.Data.SQLite;
using System.Data;

namespace Filmi

{
    public partial class Form1 : Form
    {
        string povNiz = @"Data Source=C:\Users\damij\Desktop\filmi.sqlite; Version=3;";
        private SQLiteConnection povezava;

        public Form1()

        {
            InitializeComponent();
            NajboljsiFilmi.Items.Clear();
            Lastnost.Items.Clear();
            this.povezava = new SQLiteConnection(this.povNiz);
            SQLiteCommand ukaz = new SQLiteCommand();
            ukaz.Connection = povezava;
            ukaz.CommandType = CommandType.Text;
            //string tekst = comboBox1.Text
            //int stevilo = int.Parse(comboBox1.Text)
            ukaz.CommandText = $"select naslov, ocena from film order by ocena desc;";
            List<string> filmi = new List<string>();
            List<string> lastnost = new List<string>();
            povezava.Open();
            SQLiteDataReader reader = ukaz.ExecuteReader();
            int st = 0;
            while (reader.Read())
            {
                filmi.Add($"{st + 1}. Naslov: {reader[0]}");
                lastnost.Add($"{st + 1}. Ocena: { reader[1]}");
                st++;
            }
            reader.Close();
            povezava.Close();
            int i = 0;
            foreach (string film in filmi)
            {
                NajboljsiFilmi.Items.Add(film);
                Lastnost.Items.Add(lastnost[i]);
                i++;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            NajboljsiFilmi.Items.Clear();
            Lastnost.Items.Clear();
            this.povezava = new SQLiteConnection(this.povNiz);
            SQLiteCommand ukaz = new SQLiteCommand();
            ukaz.Connection = povezava;
            ukaz.CommandType = CommandType.Text;
            //string tekst = comboBox1.Text
            //int stevilo = int.Parse(comboBox1.Text)
            ukaz.CommandText = $"select naslov, dolzina from film where dolzina > {int.Parse(comboBox1.Text)} order by dolzina;";
            List<string> filmi = new List<string>();
            List<string> lastnost = new List<string>();
            povezava.Open();
            SQLiteDataReader reader = ukaz.ExecuteReader();
            int st = 0;
            while (reader.Read())
            {
                filmi.Add($"{st+1}. Naslov: {reader[0]}");
                lastnost.Add($"{st + 1}. Dol�ina: { reader[1]}");
                st++;
            }
            reader.Close();
            povezava.Close();
            int i = 0;
            foreach (string film in filmi)
            {
                NajboljsiFilmi.Items.Add(film);
                Lastnost.Items.Add(lastnost[i]); 
                i++;
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            NajboljsiFilmi.Items.Clear();
            Lastnost.Items.Clear();    
            this.povezava = new SQLiteConnection(this.povNiz);
            SQLiteCommand ukaz = new SQLiteCommand();
            ukaz.Connection = povezava;
            ukaz.CommandType = CommandType.Text;
            ukaz.CommandText = $"select naslov, leto from film where leto > {int.Parse(comboBox2.Text)} order by leto;";
            List<string> filmi = new List<string>();
            List<string> lastnost = new List<string>();
            povezava.Open();
            SQLiteDataReader reader = ukaz.ExecuteReader();
            int st = 0;
            while (reader.Read())
            {
                filmi.Add($"{st + 1}. Naslov: {reader[0]}");
                lastnost.Add($"{st + 1}. Leto: { reader[1]}");
                st++;
            }
            reader.Close();
            povezava.Close();
            int i = 0;
            foreach (string film in filmi)
            {
                NajboljsiFilmi.Items.Add(film);
                Lastnost.Items.Add(lastnost[i]);
                i++;
            }
        }
    }
}